const request = require('supertest');
const expect = require('chai').expect;

describe('API tests using supertest for get current price', () => {
	const baseurl = 'api.coindesk.com';
	it('Verify current price', (done) => {
		request(baseurl)
			.get('/v1/bpi/currentprice.json')
			.set('Accept', 'application/json')
			.set('Content-Type', 'application/json')
			.end(function (err, res) {
				expect(res.statusCode).to.be.equal(200);
				// response contains There are 3 BPIs
				expect(res.body.bpi).to.have.key("USD", "GBP", "EUR");
				// Assertion for GBP description
				expect(res.body.bpi.GBP.description).to.be.contains("British Pound Sterling");
				done();
			});
	});
});
